package tut01.tanks.enums;

public enum TankDirection {
    UP, DOWN, LEFT, RIGHT;
}
