package tut01.tanks.enums;

public enum EnemyTankType {
    BASIC, FAST, POWER, ARMOR
}
