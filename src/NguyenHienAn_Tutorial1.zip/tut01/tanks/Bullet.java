package tut01.tanks;

public class Bullet {
}
